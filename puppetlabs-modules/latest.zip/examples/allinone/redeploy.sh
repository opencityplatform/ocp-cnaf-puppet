#!/bin/bash

./11_setup_openstack.sh
