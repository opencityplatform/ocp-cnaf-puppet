vagrant destroy -f
