#!/bin/bash
# Run tempest
vagrant ssh allinone -c "sudo /openstack/examples/allinone/run_tempest.sh"
