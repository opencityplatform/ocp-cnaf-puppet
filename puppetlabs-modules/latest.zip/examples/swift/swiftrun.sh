#!/bin/bash
./05_swiftup
./10_setup_master.sh
./11_setup_havana.sh
./15_setup_swiftnodes.sh
./25_deploy_swiftstore.sh
./30_deploy_control.sh
./25_deploy_swiftstore.sh
