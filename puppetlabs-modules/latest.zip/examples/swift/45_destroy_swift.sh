vagrant destroy -f puppet control swiftstore1 swiftstore2 swiftstore3
