vagrant destroy -f puppet control storage network compute
vagrant destroy -f tempest
